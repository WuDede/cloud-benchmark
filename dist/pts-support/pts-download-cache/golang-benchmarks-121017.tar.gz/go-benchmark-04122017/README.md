# go-benchmark
All in one go-benchmark
