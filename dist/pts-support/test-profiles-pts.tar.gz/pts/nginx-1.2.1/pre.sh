#!/bin/sh
./nginx_/sbin/nginx
sleep 5
