#!/bin/sh

dd if=/dev/zero of=encryptfile bs=1M count=2048

