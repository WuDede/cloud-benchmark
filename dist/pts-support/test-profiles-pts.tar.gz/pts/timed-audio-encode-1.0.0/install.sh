#!/bin/sh

tar -zxvf pts-trondheim-wav-3.tar.gz
mv pts-trondheim-3.wav pts-trondheim.wav
