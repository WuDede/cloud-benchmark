#!/bin/sh
diskutil eject /Volumes/Warsow\ 0.61/

