#!/bin/sh

hdid Warsow\ 0.61.dmg
