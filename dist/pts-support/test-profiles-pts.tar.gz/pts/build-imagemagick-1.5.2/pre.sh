#!/bin/sh
tar -xjf ImageMagick-6.6.3-4.tar.bz2
cd ImageMagick-6.6.3-4/
./configure > /dev/null
make clean
