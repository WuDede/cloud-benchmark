#!/bin/sh

rm -rf ImageMagick-6.6.3-2/

