#!/bin/sh
cd ImageMagick-6.6.3-4/
make clean
