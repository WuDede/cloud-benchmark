#!/bin/sh

rm -f *.bdf
