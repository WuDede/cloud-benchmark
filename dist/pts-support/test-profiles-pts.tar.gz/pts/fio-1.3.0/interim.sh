#!/bin/sh

cd fio-2.1.9/
rm -f iometer.1.0
