#!/bin/sh

rm -f *.ppm

