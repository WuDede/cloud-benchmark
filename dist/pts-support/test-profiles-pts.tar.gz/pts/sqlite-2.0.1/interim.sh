#!/bin/sh

rm -f benchmark.db
